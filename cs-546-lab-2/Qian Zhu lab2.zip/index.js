const printShape = require("./printShape");

let t = printShape.triangle(6);
console.log(t);
let t1 = printShape.triangle(8);
console.log(t1);
let q = printShape.square(6);
console.log(q);
let q1 = printShape.square(8);
console.log(q1);
let r = printShape.rhombus(6);
console.log(r);
let r1 = printShape.rhombus(8);
console.log(r1);